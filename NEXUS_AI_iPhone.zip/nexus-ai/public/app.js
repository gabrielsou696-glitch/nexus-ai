const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const STORAGE = "nexus-ai-tasks-v1";
let tasks = JSON.parse(localStorage.getItem(STORAGE) || "[]");
let filter = "all", editingId = null, history = [];
const today = new Date();
$("#todayLabel").textContent = today.toLocaleDateString("pt-BR",{weekday:"short",day:"2-digit",month:"short"});
const dateISO = d => d ? new Date(d+"T12:00:00").toLocaleDateString("pt-BR") : "Sem prazo";
const save = () => { localStorage.setItem(STORAGE, JSON.stringify(tasks)); render(); };
const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function go(view){
  $$(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${view}`));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  $("#pageTitle").textContent=({home:"Visão geral",tasks:"Minhas tarefas",assistant:"Assistente IA",reports:"Relatórios"})[view];
  if(view==="assistant") setTimeout(()=>$("#chatInput").focus(),80);
}
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.view)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
function taskMarkup(t){
  return `<div class="task-row">
    <button class="task-check ${t.done?"done":""}" data-toggle="${t.id}" aria-label="Concluir tarefa">${t.done?"✓":""}</button>
    <div class="task-main"><div class="task-title ${t.done?"done":""}">${esc(t.title)}</div><div class="task-meta">${dateISO(t.due)}${t.notes?" · "+esc(t.notes):""}</div></div>
    <span class="priority ${t.priority}">${t.priority==="high"?"Alta":t.priority==="low"?"Baixa":"Normal"}</span>
    <div class="task-actions"><button class="icon-btn" data-edit="${t.id}" aria-label="Editar">✎</button><button class="icon-btn" data-delete="${t.id}" aria-label="Excluir">×</button></div>
  </div>`;
}
function bindTaskButtons(){
  $$("[data-toggle]").forEach(b=>b.onclick=()=>{const t=tasks.find(x=>x.id===b.dataset.toggle);if(t){t.done=!t.done;save();}});
  $$("[data-delete]").forEach(b=>b.onclick=()=>{tasks=tasks.filter(x=>x.id!==b.dataset.delete);save();});
  $$("[data-edit]").forEach(b=>b.onclick=()=>openTask(b.dataset.edit));
}
function render(){
  const total=tasks.length, done=tasks.filter(t=>t.done).length, open=total-done, pct=total?Math.round(done/total*100):0;
  $("#totalCount").textContent=total;$("#doneCount").textContent=done;$("#openCount").textContent=open;$("#progressValue").textContent=pct+"%";$("#progressBar").style.width=pct+"%";
  const sorted=[...tasks].sort((a,b)=>(a.done-b.done)||((a.due||"9999").localeCompare(b.due||"9999")));
  const home=sorted.filter(t=>!t.done).slice(0,4);
  $("#homeTaskList").innerHTML=home.length?home.map(taskMarkup).join(""):'<div class="empty-state">Tudo em dia por aqui. Adicione uma atividade quando precisar.</div>';
  const visible=sorted.filter(t=>filter==="all"||(filter==="done"?t.done:!t.done));
  $("#taskList").innerHTML=visible.length?visible.map(taskMarkup).join(""):'<div class="empty-state">Nenhuma tarefa nesta categoria.</div>';
  bindTaskButtons();
  $("#reportRate").textContent=pct+"%";$("#reportBar").style.width=pct+"%";$("#reportPending").textContent=open;
  const overdue=tasks.filter(t=>!t.done&&t.due&&t.due<new Date().toISOString().slice(0,10)).length;
  $("#reportSummary").textContent=`Você cadastrou ${total} tarefa(s). ${done} concluída(s) e ${open} em aberto. ${overdue} tarefa(s) com prazo vencido. ${pct>=75&&total?"Ótimo ritmo de conclusão.":total?"Continue avançando uma atividade de cada vez.":"Cadastre suas atividades para começar a acompanhar seu progresso."}`;
}
$$("[data-filter]").forEach(b=>b.onclick=()=>{filter=b.dataset.filter;$$("[data-filter]").forEach(x=>x.classList.toggle("active",x===b));render();});
function openTask(id=null){
  editingId=id;const t=tasks.find(x=>x.id===id);
  $("#dialogTitle").textContent=t?"Editar tarefa":"Adicionar tarefa";
  $("#taskTitle").value=t?.title||"";$("#taskDue").value=t?.due||"";$("#taskPriority").value=t?.priority||"normal";$("#taskNotes").value=t?.notes||"";
  $("#taskDialog").showModal();
}
$("#newTaskBtn").onclick=()=>openTask();$("#closeDialog").onclick=()=>$("#taskDialog").close();
$("#taskForm").onsubmit=e=>{
  e.preventDefault();const data={title:$("#taskTitle").value.trim(),due:$("#taskDue").value,priority:$("#taskPriority").value,notes:$("#taskNotes").value.trim()};
  if(!data.title)return;
  if(editingId){tasks=tasks.map(t=>t.id===editingId?{...t,...data}:t);}
  else tasks.push({id:crypto.randomUUID(),...data,done:false,createdAt:new Date().toISOString()});
  $("#taskDialog").close();save();
};
function addBubble(text,role){const el=document.createElement("div");el.className=`bubble ${role}`;el.textContent=text;$("#chatMessages").append(el);$("#chatMessages").scrollTop=$("#chatMessages").scrollHeight;}
async function askAI(message){
  if(!message.trim())return;
  addBubble(message,"user");history.push({role:"user",content:message});$("#chatInput").value="";
  const loading=document.createElement("div");loading.className="bubble assistant";loading.textContent="Pensando…";$("#chatMessages").append(loading);
  try{
    const r=await fetch("/api/assistant",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,tasks,history:history.slice(-8)})});
    const data=await r.json();if(!r.ok)throw new Error(data.error||"Erro ao consultar a IA.");
    loading.textContent=data.answer;history.push({role:"assistant",content:data.answer});
  }catch(err){loading.textContent=err.message;}
  $("#chatMessages").scrollTop=$("#chatMessages").scrollHeight;
}
$("#chatForm").onsubmit=e=>{e.preventDefault();askAI($("#chatInput").value);};
$$("[data-prompt]").forEach(b=>b.onclick=()=>askAI(b.dataset.prompt));
$("#exportReport").onclick=()=>{
  const total=tasks.length,done=tasks.filter(t=>t.done).length,open=total-done;
  const lines=["NEXUS AI — RELATÓRIO DE ATIVIDADES",`Gerado em: ${new Date().toLocaleString("pt-BR")}`,"",`Total: ${total}`,`Concluídas: ${done}`,`Em aberto: ${open}`,`Taxa de conclusão: ${total?Math.round(done/total*100):0}%`,"","LISTA DE ATIVIDADES",...tasks.map(t=>`[${t.done?"X":" "}] ${t.title} | Prazo: ${dateISO(t.due)} | Prioridade: ${t.priority}`)];
  const blob=new Blob([lines.join("\n")],{type:"text/plain;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="relatorio-nexus.txt";a.click();URL.revokeObjectURL(url);
};
async function checkAI(){try{const r=await fetch("/api/status");const d=await r.json();$("#aiStatus").textContent=d.aiConfigured?"IA conectada":"IA aguardando configuração";}catch{$("#aiStatus").textContent="Servidor indisponível";}}
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
render();checkAI();
