# NEXUS AI — MVP instalável no iPhone

NEXUS é um aplicativo web progressivo (PWA): abre no Safari e pode ser adicionado à Tela de Início do iPhone 11. Inclui painel, cadastro/edição/conclusão/exclusão de tarefas, filtros, indicadores, exportação de relatório `.txt` e chat com IA via servidor.

## Requisitos
- Node.js 20 ou superior
- Uma chave de API da OpenAI para habilitar o assistente (a API é cobrada separadamente do ChatGPT)
- Hospedagem HTTPS para instalar no iPhone como PWA

## Rodar localmente
1. Extraia o ZIP e abra a pasta no terminal.
2. Execute `npm install`.
3. Copie `.env.example` para `.env`.
4. Coloque sua chave em `OPENAI_API_KEY`. Nunca coloque a chave em `public/` nem no JavaScript do navegador.
5. Execute `npm start`.
6. Abra `http://localhost:3000` no computador para testar.

O modelo pode ser alterado em `OPENAI_MODEL` conforme os modelos disponíveis na sua conta da API.

## Instalar no iPhone 11
1. Publique a pasta/projeto em um servidor Node com HTTPS (por exemplo, uma hospedagem que aceite Node).
2. Abra o endereço HTTPS no Safari do iPhone.
3. Toque em Compartilhar → Adicionar à Tela de Início → Adicionar.
4. Abra pelo ícone NEXUS AI.

## O que já funciona
- Tarefas guardadas no armazenamento local do navegador do aparelho.
- Prioridade, prazo, observações, edição, exclusão e conclusão.
- Painel com contagens e taxa de conclusão.
- Relatório local exportável em TXT.
- Assistente IA que recebe a mensagem e uma cópia resumida das tarefas atuais.
- Estrutura PWA e cache básico da interface.

## Limites desta primeira versão
- As tarefas ficam no aparelho/navegador; não há sincronização entre dispositivos nem conta/login.
- A IA conversa, analisa e sugere, mas ainda não altera tarefas automaticamente. Confirme e registre manualmente as ações sugeridas.
- Não envia e-mails, não cria eventos no Calendário e não controla outros aplicativos.
- Notificações push e lembretes programados ainda não estão implementados.
- Para dados importantes, mantenha backup. O armazenamento local pode ser apagado pelo sistema/navegador.

## Segurança e produção
Antes de disponibilizar publicamente, adicione autenticação, limites de requisição, proteção contra abuso, política de privacidade e banco de dados com backup. A chave da API permanece apenas no servidor. Não compartilhe o arquivo `.env`.
