import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/assistant", async (req, res) => {
  const { message, tasks = [], history = [] } = req.body ?? {};
  if (typeof message !== "string" || !message.trim()) {
    return res.status(400).json({ error: "Escreva uma mensagem." });
  }
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({
      error: "A IA ainda não foi conectada. Configure OPENAI_API_KEY no arquivo .env."
    });
  }

  const taskSummary = Array.isArray(tasks) ? tasks.slice(0, 100).map(t => ({
    title: String(t.title ?? "").slice(0, 160),
    due: t.due ?? null,
    priority: t.priority ?? "normal",
    done: Boolean(t.done)
  })) : [];

  const safeHistory = Array.isArray(history) ? history.slice(-8).map(m => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: String(m.content ?? "").slice(0, 3000)
  })) : [];

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6-luna",
        instructions: [
          "Você é o NEXUS, assistente pessoal de produtividade em português do Brasil.",
          "Ajude a organizar tarefas, planejar rotinas, identificar prioridades e redigir relatórios.",
          "Use os dados de tarefas fornecidos; não invente atividades concluídas, prazos ou resultados.",
          "Se faltarem dados, diga claramente o que está faltando. Seja objetivo e acolhedor.",
          "Você pode sugerir ações, mas não afirme que alterou agenda, enviou mensagens ou executou ações externas."
        ].join(" "),
        input: [
          ...safeHistory,
          { role: "user", content: `Tarefas atuais (JSON): ${JSON.stringify(taskSummary)}\n\nPedido: ${message}` }
        ],
        max_output_tokens: 900
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("OpenAI API error:", data);
      return res.status(response.status).json({
        error: data?.error?.message || "Não foi possível obter resposta da IA."
      });
    }

    const answer = data.output_text ||
      (data.output || []).flatMap(item => item.content || [])
        .filter(item => item.type === "output_text")
        .map(item => item.text).join("\n");

    res.json({ answer: answer || "Não consegui formular uma resposta. Tente novamente." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Falha de conexão com o serviço de IA." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NEXUS AI disponível em http://localhost:${port}`));
